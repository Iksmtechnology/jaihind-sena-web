export const environment = {
    production: true,
    // apiBaseUrl: 'http://amkore7-001-site1.ltempurl.com/'
    apiBaseUrl: 'http://localhost:3000'
};
