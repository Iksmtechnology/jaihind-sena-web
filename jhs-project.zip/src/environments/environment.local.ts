export const environment = {
    production: false,
    apiBaseUrl: 'http://amkore7-001-site1.ltempurl.com/'
};
