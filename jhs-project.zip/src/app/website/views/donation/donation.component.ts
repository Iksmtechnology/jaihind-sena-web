import { Component, HostListener } from '@angular/core';
import { RazorpayService } from '../../../services/razorpay.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-donation',
  imports: [CommonModule,RouterModule,
    ReactiveFormsModule,
    FormsModule],
  templateUrl: './donation.component.html',
  styleUrl: './donation.component.scss'
})
export class DonationComponent {

 donationForm!: FormGroup;
  amounts = [1000, 2000, 5000, 10000, 20000];
  selectedAmount: number | null = null;

  constructor(private fb: FormBuilder, private razorpayService: RazorpayService,private router: Router, private route: ActivatedRoute,) {
  }


ngOnInit() {
    this.donationForm = this.fb.group({
      fullName: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      pan: [''],
      pincode: [''],
      referrerPhone: [''],
      confirmAge: [false, Validators.requiredTrue],
      amount: ['', Validators.required],
    });

   this.route.queryParams.subscribe(params => {
  const amount = +params['amount'] || 0;

  // Patch into donation form instead of a separate variable
  this.donationForm.patchValue({ amount });

  if (amount > 0) {
    this.razorpayService.openPayment(amount);
  }
});

       const storedLang = localStorage.getItem('lang') as 'en' | 'mr';
    if (storedLang) {
      this.selectedLang = storedLang;
    }

  }


  selectedLang: 'en' | 'mr' = 'en';




  onSubmit() {
    if (this.donationForm.valid) {
      console.log('Form Values:', this.donationForm.value);
      // You can send this data to Razorpay API or backend
    } else {
      console.log('Form is invalid');
      this.donationForm.markAllAsTouched();
    }
  }

  //  amount: number = 200; // default

onDonate() {
   const minAmount = 1; // set minimum donation to ₹1 (not 0)
  const amount = this.donationForm.get('amount')?.value;

  if (this.donationForm.invalid) {
    this.donationForm.markAllAsTouched();
    return;
  }

  if (!amount || amount < minAmount) {
    alert(`Minimum donation is ₹${minAmount}`);
    return;
  }

   // Call Razorpay service
  this.razorpayService.openPayment(amount);
}


  setAmount(value: number) {
    this.selectedAmount = value;
    console.log(this.selectedAmount,'selectedAmount')
    this.donationForm.patchValue({ amount: value });
  }

  toggleLanguage() {
    this.selectedLang = this.selectedLang === 'en' ? 'mr' : 'en';
    localStorage.setItem('lang', this.selectedLang);
    location.reload(); // Refresh to re-render text if needed
  }

   isScrolled = false;
  @HostListener('window:scroll', [])
  onWindowScroll() {
    // Add scrolled class after 50px
    this.isScrolled = window.scrollY > 50;
  }

    activeSection = 'home';
  onSectionChange(sectionId: any) {
    this.activeSection = sectionId;
  }

}
