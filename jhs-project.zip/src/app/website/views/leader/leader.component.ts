import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import Swal from 'sweetalert2';
import { SupabaseApiService } from '../../../services/supabase-api.service';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-leader',
   imports: [FormsModule, CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './leader.component.html',
  styleUrl: './leader.component.scss'
})
export class LeaderComponent {

  selectedLang: 'en' | 'mr' = 'en'; // or dynamically detect/set
  contactForm: FormGroup;
  isScrolled = false;

leaderContent = [
  {
    id: 1,
    title: {
      en: 'Shri. Chandan Dada Chavan',
      mr: 'श्री. चंदनदादा चव्हाण'
    },
    subtitle: {
      en: 'Party Chief: Jai Hind Sena, Maharashtra State.',
      mr: 'पक्षप्रमुख : जय हिंद सेना, महाराष्ट्र राज्य.'
    },
      image: 'assets/image/leader-image.png',
    paragraphs: [
      {
        en: 'Land holders in "Gunthawari" do not require a new law to have their names added to the 7/12 extract – Shri Chandan Dada Chavan.',
        mr: 'गुंठेवारी धारकांना ७/१२ वर नावे लागण्यासाठी नव्या कायद्याची गरज नाही – चंदनदादा चव्हाण.'
      },
      {
        en: 'In Maharashtra’s political landscape, Shri Chandan Dada Chavan stands as a dedicated leader with a deep connection to the people.',
        mr: 'महाराष्ट्राच्या राजकीय क्षेत्रात श्री. चंदनदादा चव्हाण हे जनतेशी घट्ट नातं ठेवणारे समर्पित नेते म्हणून उभे आहेत.'
      },
      {
        en: 'With commitment and passion, he has been instrumental in bringing transformative changes for the welfare of citizens.',
        mr: 'समर्पण आणि जिद्दीने त्यांनी नागरिकांच्या कल्याणासाठी परिवर्तनकारी बदल घडवून आणले आहेत.'
      }
    ]
  },
  {
    id: 2,
    title: {
      en: 'Shri. Ranjit Chavan',
      mr: 'श्री. रंजीत चव्हाण'
    },
    subtitle: {
      en: 'Senior Leader: Jai Hind Sena, Maharashtra State.',
      mr: 'वरिष्ठ नेते : जय हिंद सेना, महाराष्ट्र राज्य.'
    },
      image: 'assets/image/rannji-chavan.png',
    paragraphs: [
      {
        en: 'Shri Ranjit Chavan has been actively working at the grassroots level to empower youth and farmers.',
        mr: 'श्री. रंजीत चव्हाण युवक व शेतकऱ्यांच्या सक्षमीकरणासाठी तळागाळात सक्रियपणे कार्यरत आहेत.'
      },
      {
        en: 'With his strong vision, he continues to strengthen the organizational structure of Jai Hind Sena across Maharashtra.',
        mr: 'त्यांच्या ठाम दृष्टिकोनामुळे ते महाराष्ट्रभर जय हिंद सेनेची संघटनात्मक रचना मजबूत करत आहेत.'
      },
      {
        en: 'Known for his dedication and accessibility, he remains a trusted leader among people.',
        mr: 'समर्पण व सहज उपलब्धतेमुळे ते जनतेत विश्वासार्ह नेते म्हणून ओळखले जातात.'
      }
    ]
  }
];
leaderId: any;
 leaderContents: any;

  constructor(private route: ActivatedRoute,private userService:UserService, private supabaseService: SupabaseApiService, private http: HttpClient, private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      subject: [''],
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      contact: ['', [Validators.required]],
      message: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
 const id = Number(this.route.snapshot.paramMap.get('id'));
    this.leaderContents = this.leaderContent.find(l => l.id === id);

    const storedLang = localStorage.getItem('lang') as 'en' | 'mr';
    if (storedLang) {
      this.selectedLang = storedLang;
    }
  }

  onSubmit() {
    if (this.contactForm.valid) {
      this.userService.postpassDataApi(this.contactForm.value).subscribe({
        next: () => {

          Swal.fire('Success', 'Message sent successfully!', 'success');
          // this.contactForm.reset();
        },
        error: (err) => {
          const message = err?.error?.message || 'Something went wrong.';
          Swal.fire('Error', message, 'error');
        }
      });
      this.contactForm.reset();
    } else {
      this.contactForm.markAllAsTouched();
    }
  }



  @HostListener('window:scroll', [])
  onWindowScroll() {
    // Add scrolled class after 50px
    this.isScrolled = window.scrollY > 50;
  }

  toggleLanguage() {
    this.selectedLang = this.selectedLang === 'en' ? 'mr' : 'en';
    localStorage.setItem('lang', this.selectedLang);
    location.reload(); // Refresh to re-render text if needed
  }

  activeSection = 'home';
  onSectionChange(sectionId: any) {
    this.activeSection = sectionId;
  }
}
